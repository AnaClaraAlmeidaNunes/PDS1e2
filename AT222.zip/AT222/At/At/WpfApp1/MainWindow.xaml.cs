﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtusuario_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string usuario = txtusuario.Text;
            string senha =txtsenha.Password.ToString();
            if (usuario == "cliente_20@gmail.com")
                MessageBox.Show("usuario válido", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            else MessageBox.Show("usuario inválido", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            if(senha == "1000")
                MessageBox.Show("senha válida", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            else MessageBox.Show("senha inválida", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            Window2222 tela2 = new Window2222();
            tela2.ShowDialog();
        }
    }
}
