﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica interna para sla.xaml
    /// </summary>
    public partial class sla : Window
    {
        public sla()
        {
            InitializeComponent();
        }

        private void btEntrar_Click(object sender, RoutedEventArgs e)
        {
            string usuario = txtEmail.Text;
            string senha = Pssenha.Password.ToString();
            if (usuario == "cliente_20@gmail.com")
                MessageBox.Show("usuario válido", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            else MessageBox.Show("usuario inválido", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            if (senha == "1000")
                MessageBox.Show("senha válida", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            else MessageBox.Show("senha inválida", "confirmação de login", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            MainWindow tela2 = new MainWindow();
            tela2.ShowDialog();
        }
    }
}
