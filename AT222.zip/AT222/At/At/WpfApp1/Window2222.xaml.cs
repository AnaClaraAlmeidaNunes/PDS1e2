﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica interna para Window2222.xaml
    /// </summary>
    public partial class Window2222 : Window
    {
        public Window2222()
        {
            InitializeComponent();
        }

        private void btmais1_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(txtprimeiro.Text);
            double b = Convert.ToDouble(txtsegundo.Text);
            double t = a + b;
            txtresulta.Text = a.ToString() + "+" + b.ToString() + "=" + t.ToString();
        }

        private void btmenos_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(txtprimeiro.Text);
            double b = Convert.ToDouble(txtsegundo.Text);
            double t = a - b;
            txtresulta.Text = a.ToString() + "-" + b.ToString() + "=" + t.ToString();
        }

        private void btvezes_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(txtprimeiro.Text);
            double b = Convert.ToDouble(txtsegundo.Text);
            double t = a * b;
            txtresulta.Text = a.ToString() + "*" + b.ToString() + "=" + t.ToString();
        }

        private void btdiv_Click(object sender, RoutedEventArgs e)
        {
            double a = Convert.ToDouble(txtprimeiro.Text);
            double b = Convert.ToDouble(txtsegundo.Text);
            double t = a / b;
            txtresulta.Text = a.ToString() + "/" + b.ToString() + "=" + t.ToString();
        }
    }
}
